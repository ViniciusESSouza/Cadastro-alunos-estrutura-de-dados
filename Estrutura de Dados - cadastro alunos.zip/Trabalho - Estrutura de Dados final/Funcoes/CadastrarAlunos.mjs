import { stdin, stdout } from 'node:process';
import { writeFile } from 'node:fs/promises';

export async function cadastrarAluno(alunos) {
    let etapaCadastro = 'nome';
    const novoAluno = {};

    function perguntar() {
        switch (etapaCadastro) {
            case 'nome':
                stdout.write('Nome: ');
                break;
            case 'ra':
                stdout.write('RA: ');
                break;
            case 'idade':
                stdout.write('Idade: ');
                break;
            case 'sexo':
                stdout.write('Sexo (F para Feminino | M para Masculino): ');
                break;
            case 'media':
                stdout.write('Média: ');
                break;
            case 'finalizar':
                if (novoAluno.media > 5) {
                    novoAluno.resultado = 'Aprovado';
                } else {
                    novoAluno.resultado = 'Reprovado';
                }
                alunos.push(novoAluno);
                console.log('Aluno adicionado (dentro da função):', novoAluno);
                console.log('Lista de alunos (dentro da função):', alunos);
                break;
        }
    }

    stdin.on('data', (data) => {
        const resposta = String(data).trim();

        switch (etapaCadastro) {
            case 'nome':
                novoAluno.nome = resposta;
                etapaCadastro = 'ra';
                perguntar();
                break;
            case 'ra':
                novoAluno.ra = resposta;
                etapaCadastro = 'idade';
                perguntar();
                break;
            case 'idade':
                novoAluno.idade = parseInt(resposta);
                etapaCadastro = 'sexo';
                perguntar();
                break;
            case 'sexo':
                novoAluno.sexo = resposta;
                etapaCadastro = 'media';
                perguntar();
                break;
            case 'media':
                novoAluno.media = parseFloat(resposta);
                etapaCadastro = 'finalizar';
                perguntar();
                break;
        }
    });

    perguntar();
}

cadastrarAluno([]);