export function ordbyResultado(vetor) {
    const alunosAprovados = vetor.filter(aluno => aluno.resultado === 'Aprovado');
    
    for (let posSel = 0; posSel < alunosAprovados.length - 1; posSel++) {
        let posMenor = posSel;

        for (let i = posSel + 1; i < alunosAprovados.length; i++) {
            if (alunosAprovados[i].nome.localeCompare(alunosAprovados[posMenor].nome) < 0) {
                posMenor = i;
            }
        }

        if (posMenor !== posSel) {
            [alunosAprovados[posSel], alunosAprovados[posMenor]] = [alunosAprovados[posMenor], alunosAprovados[posSel]];
        }
    }

    return alunosAprovados;
}