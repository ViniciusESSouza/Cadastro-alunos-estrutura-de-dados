export function ordByNome(vetor) {

    for (let posSel = 0; posSel < vetor.length - 1; posSel++) {
        let posMenor = posSel;

        for (let i = posSel + 1; i < vetor.length; i++) {

            if (vetor[i].nome.localeCompare(vetor[posMenor].nome) < 0) {
                posMenor = i;
            }
        }


        if (posMenor !== posSel) {
            [vetor[posSel], vetor[posMenor]] = [vetor[posMenor], vetor[posSel]];
        }
    }

    return vetor; 
}