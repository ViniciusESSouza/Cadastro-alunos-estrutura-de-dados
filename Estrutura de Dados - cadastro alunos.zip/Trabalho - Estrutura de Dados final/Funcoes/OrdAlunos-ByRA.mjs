export function ordByRA(vetor) {

    for (let posSel = 0; posSel < vetor.length - 1; posSel++) {
        let posMenor = posSel;

        for (let i = posSel + 1; i < vetor.length; i++) {

            if (parseInt(vetor[i].ra) < parseInt(vetor[posMenor].ra)) {
                posMenor = i;
            }
        }

        if (posMenor !== posSel) {
            [vetor[posSel], vetor[posMenor]] = [vetor[posMenor], vetor[posSel]];
        }
    }

    return vetor; 
}