import { AlunosCadastrados as alunos} from './Base de Dados/Alunos.mjs'
import { stdin } from 'node:process'
import { cadastrarAluno } from './Funcoes/CadastrarAlunos.mjs'
import { ordByNome } from './Funcoes/OrdAlunos-ByNome.mjs'
import { ordByRA } from './Funcoes/OrdAlunos-ByRA.mjs'
import { ordbyResultado } from './Funcoes/OrdAlunos_Aprovados-ByNome.mjs'

function main(){
    console.log('Entre com uma das opções abaixo:')
    console.log()

    console.log('1. Cadastrar alunos.')
    console.log('2. Relatório de alunos em ordem crescente por Nome.')
    console.log('3. Relatório de alunos em ordem crescente por RA.')
    console.log('4. Relatório de alunos em ordem crescente por Nome, apenas dos APROVADOS.')
    console.log('5. Encerre a execução do programa.')
}

main()

    stdin.on('data', (OpEscolhida) => {
        const escolha = String(OpEscolhida).trim();
        
        if (escolha === '1' || escolha === '2' || escolha === '3' || escolha === '4' || escolha === '5') {
          switch (escolha) {
            case '1':
              console.log('\nOpção Selecionada: Cadastrar alunos.');
                cadastrarAluno(alunos);
              break;
      
            case '2':
              console.log('\nOpção Selecionada: Relatório de alunos em ordem crescente por Nome.');
                console.log(ordByNome(alunos));
              break;
      
            case '3':
              console.log('\nOpção Selecionada: Relatório de alunos em ordem crescente por RA.');
                console.log(ordByRA(alunos));
              break;
      
            case '4':
              console.log('\nOpção Selecionada: Relatório de alunos aprovados em ordem crescente por Nome.');
                console.log(ordbyResultado(alunos));
              break;
      
            case '5':
              console.log('\nEncerrando o programa.');
              process.exit();
              break;
          }
        } else {
          console.log('\nO que foi digitado não confere com as opções, encerrando programa.');
          process.exit();
        }
      });